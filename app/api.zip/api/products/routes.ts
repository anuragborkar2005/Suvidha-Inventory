import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    const products = await prisma.product.findMany({
      orderBy: { name: "asc" }
    });
    return NextResponse.json(products);
  } catch (e) {
    console.error("Product fetch failed:", e);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}
