import { GalleryVerticalEnd } from "lucide-react";
import { Suspense } from "react";
import { SignupForm } from "@/components/signup-form";
import Image from "next/image";
import { Spinner } from "@/components/ui/spinner";

function Loading() {
    return (
        <div className="flex min-h-screen items-center justify-center">
            <Spinner className="size-8 animate-spin" />
        </div>
    );
}

export default function SignupPage() {
    return (
        <div className="grid min-h-svh lg:grid-cols-2">
            <div className="flex flex-col gap-4 p-6 md:p-10">
                <div className="flex justify-center gap-2 md:justify-start">
                    <a href="#" className="flex items-center gap-2 font-medium">
                        <div className="bg-primary text-primary-foreground flex size-6 items-center justify-center rounded-md">
                            <GalleryVerticalEnd className="size-4" />
                        </div>
                        Suvidha Inventory
                    </a>
                </div>
                <div className="flex flex-1 items-center justify-center">
                    <div className="w-full max-w-sm">
                        <Suspense fallback={<Loading />}>
                            <SignupForm />
                        </Suspense>
                    </div>
                </div>
            </div>
            <div className="bg-muted relative hidden lg:block">
                <Image
                    src="https://placehold.co/900x900/png"
                    alt="Image"
                    className="absolute inset-0 h-full w-full object-cover dark:brightness-[0.2] dark:grayscale"
                    fill
                />
            </div>
        </div>
    );
}
